from setuptools import setup
import os

with open("README.md", "r") as readme_file:
    readme = readme_file.read()

setup(name='cardify',
      version='0.0.1',
      description='Automate your christmas card creation!',
      long_description=open("README.md").read(),
      long_description_content_type='text/markdown',
      author='Rahul Prabhu',
      author_email='rahul@grokwithrahul.com',
      url='https://github.com/grokwithrahul/christmas-card-creator',
      packages=['cardify'],
      install_requires=['Pillow', 'sketchify'],
      package_data={'cardify':['Brusher.ttf', 'defaultbg.png']}
     )